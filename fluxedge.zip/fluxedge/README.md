# fluxai-fluxedge
files for deploying fluxai on fluxedge, other possible hosts
